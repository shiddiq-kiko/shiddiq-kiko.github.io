param(
    [string]$ReminderMessage,
    [string]$TaskName = $null
)

$LogFile = Join-Path $PSScriptRoot "reminder_debug.log"
"--- Reminder triggered at $(Get-Date) ---" | Out-File $LogFile -Append
"Message: $ReminderMessage" | Out-File $LogFile -Append
"TaskName: $TaskName" | Out-File $LogFile -Append

try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    Add-Type -AssemblyName System.Drawing -ErrorAction Stop
    
    [System.Media.SystemSounds]::Exclamation.Play()
    
    # Use a simpler MessageBox call first to see if it works
    [System.Windows.Forms.MessageBox]::Show($ReminderMessage, "Reminder")
    
    "MessageBox closed successfully" | Out-File $LogFile -Append
}
catch {
    "ERROR: $($_.Exception.Message)" | Out-File $LogFile -Append
    $_.Exception.StackTrace | Out-File $LogFile -Append
}

if ($TaskName) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    "Task $TaskName unregistered" | Out-File $LogFile -Append
}