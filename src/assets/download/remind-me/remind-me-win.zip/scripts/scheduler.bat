@echo off
setlocal EnableDelayedExpansion

set "ACTION=%~1"
set "R_TIME=%~2"
set "NAME=%~3"
set "IS_REPEAT=%~4"

:: Shift 4 times to get message parts
shift
shift
shift
shift

set "MSG="
:loop
if "%~1"=="" goto done
if defined MSG (set "MSG=!MSG! %~1") else (set "MSG=%~1")
shift
goto loop
:done

:: Get absolute path for PowerShell script
set "SCRIPT_PATH=%~dp0\scripts\reminder.ps1"

if /I "%ACTION%"=="add" (
    if /I "%IS_REPEAT%"=="Y" (
        schtasks /create /sc DAILY /st %R_TIME% /tn %NAME% /it /tr "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%SCRIPT_PATH%\" -ReminderMessage \"%MSG%\"" /F
    ) else if /I "%IS_REPEAT%"=="y" (
        schtasks /create /sc DAILY /st %R_TIME% /tn %NAME% /it /tr "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%SCRIPT_PATH%\" -ReminderMessage \"%MSG%\"" /F
    )  else (
        schtasks /create /sc ONCE /st %R_TIME% /tn %NAME% /it /tr "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%SCRIPT_PATH%\" -ReminderMessage \"%MSG%\" -TaskName \"%NAME%\"" /RU "%USERNAME%" /F

    )
)

if /I "%ACTION%"=="remove" (
    if /I "%R_TIME%"=="ALL" (
        for /f "tokens=1 delims=," %%G in ('schtasks /query /fo csv ^| findstr /i "reminder_me-"') do (
            schtasks /delete /tn %%G /f
        )
        echo All reminders deleted.
    ) else (
        schtasks /delete /tn "%R_TIME%" /f
    )
)

if /I "%ACTION%"=="list" (
    schtasks /query /fo TABLE | findstr /i "reminder_me"
)