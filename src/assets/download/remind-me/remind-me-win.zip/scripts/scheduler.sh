#!/bin/bash

ACTION=$1
shift

if [ "$ACTION" == "add" ]; then
    TIME=$1
    NAME=$2
    IS_REPEAT=$3
    shift
    shift
    shift
    MSG="$*"
    
    # Platform detection for notification command
    if [[ "$OSTYPE" == "darwin"* ]]; then
        NOTIFY_CMD="osascript -e 'display notification \"$MSG\" with title \"Reminder\"'"
    else
        # Check if notify-send exists
        if command -v notify-send &> /dev/null; then
            NOTIFY_CMD="notify-send 'Reminder' '$MSG'"
        else
            NOTIFY_CMD="echo 'Reminder: $MSG'"
        fi
    fi
    
    if [ "$IS_REPEAT" == "Y" ] || [ "$IS_REPEAT" == "y" ]; then
        # Handle Repeating Task (Daily)
        # Using crontab
        # Extract Hour and Minute from HH:MM
        HOUR=${TIME%:*} 
        MINUTE=${TIME#*:} 
        
        # Create a unique marker for this job to find/delete it later
        JOB_MARKER="# REMINDER_COBOL $NAME"
        
        # Add to crontab
        # Format: MM HH * * * command
        (crontab -l 2>/dev/null; echo "$MINUTE $HOUR * * * $NOTIFY_CMD $JOB_MARKER") | crontab -
        
        echo "Daily reminder scheduled for $TIME."
        
    else
        # One-time Task using 'at'
        echo "$NOTIFY_CMD" | at $TIME 2>/dev/null
        
        if [ $? -eq 0 ]; then
            echo "Reminder scheduled for $TIME."
        else
            echo "Error: 'at' command failed."
        fi
    fi

elif [ "$ACTION" == "remove" ]; then
    ID_OR_NAME=$1
    if [ "$ID_OR_NAME" == "ALL" ]; then
        # Remove all cron reminders
        crontab -l 2>/dev/null | grep -v "REMINDER_COBOL" | crontab -
        # Remove all at reminders (by looking for our marker in jobs)
        for job in $(atq | cut -f1); do
            at -c $job | grep -q "REMINDER_COBOL" && atrm $job
        done
        echo "All reminders removed."
    else
        # Try removing from crontab (by name/marker)
        crontab -l 2>/dev/null | grep -v "$ID_OR_NAME" | crontab -
        # Try removing from at (by ID)
        atrm $ID_OR_NAME 2>/dev/null
        echo "Reminder removed (if it existed)."
    fi

elif [ "$ACTION" == "list" ]; then
    echo "--- One-time Reminders (at) ---"
    atq
    echo "--- Repeating Reminders (cron) ---"
    crontab -l 2>/dev/null | grep "REMINDER_COBOL"
fi