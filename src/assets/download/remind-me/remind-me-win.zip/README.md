# Remind Me (COBOL)

A lightweight command-line reminder and scheduler application built with **COBOL**. It supports Windows, Linux, and macOS by leveraging native system tools for scheduling and notifications.

## Features

- **Add Reminder**: Schedule a one-time reminder with a custom message and time.
- **List Reminders**: View currently scheduled tasks.
- **Update Reminder**: Modify an existing reminder.
- **Delete Reminder**: Remove a scheduled reminder.
- **Cross-Platform Notifications**:
    -   **Windows**: Native Toast Notifications (via PowerShell).

## Prerequisites

### Windows
1.  **Operating System**: Windows 10 or 11.
2.  **Compiler**: GnuCOBOL.
    -   `scoop install gnucobol` or `choco install gnucobol`

## How to Run

Ensure the `scripts/` directory is present in the same location as the executable.

### Windows
```powershell
.\remind_me.exe
```
## Usage

Follow the on-screen menu:
-   **Add**: Enter Time (`HH:MM`) and Message.
-   **List**:
    -   *Windows*: Shows Task Name and Next Run Time.
-   **Remove**:
    -   *Windows*: Enter the **Task Name** (e.g., `reminder_me-20260126...`).
-   **Update**: Removes the old task and adds a new one.

## Architecture

-   **COBOL**: Handles UI and logic flow. Uses `SYSTEM` calls to execute helper scripts.
-   **Scripts (`scripts/`)**:
    -   `scheduler.bat` : Abstracts the OS-specific scheduling commands.
    -   `reminder.ps1` : Handles the actual display of the notification.
