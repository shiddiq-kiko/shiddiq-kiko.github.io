# Remind Me (COBOL)

A lightweight command-line reminder and scheduler application built with **COBOL**. It supports Windows, Linux, and macOS by leveraging native system tools for scheduling and notifications.

## Features

- **Add Reminder**: Schedule a one-time reminder with a custom message and time.
- **List Reminders**: View currently scheduled tasks.
- **Update Reminder**: Modify an existing reminder.
- **Delete Reminder**: Remove a scheduled reminder.
- **Cross-Platform Notifications**:
    -   **Linux**: Desktop Notifications (via `notify-send`).
    -   **macOS**: Native Notifications (via `osascript`).

## Prerequisites

### Linux
1.  **Compiler**: GnuCOBOL (`sudo apt install gnucobol` on Debian/Ubuntu).
2.  **Tools**: `cron` (for scheduling) and `libnotify-bin` (for notifications).
    ```bash
    sudo apt install libnotify-bin
    ```

### macOS
1.  **Compiler**: GnuCOBOL (`brew install gnucobol`).
2.  **Tools**: `cron` is pre-installed.

## How to Run

Ensure the `scripts/` directory is present in the same location as the executable.

### Linux / macOS
```bash
./remind_me
```

## Usage

Follow the on-screen menu:
-   **Add**: Enter Time (`HH:MM`) and Message.
-   **List**:
    -   *Linux/Mac*: Shows scheduled cron jobs.
-   **Remove**:
    -   *Linux/Mac*: Enter the **Task Name** (seen in List).
-   **Update**: Removes the old task and adds a new one.

## Architecture

-   **COBOL**: Handles UI and logic flow. Uses `SYSTEM` calls to execute helper scripts.
-   **Scripts (`scripts/`)**:
    -   `scheduler.sh`: Abstracts the OS-specific scheduling commands.
    -   `notify-send` / `osascript`: Handles the actual display of the notification.
