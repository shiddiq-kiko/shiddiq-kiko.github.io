#!/bin/bash

ACTION=$1
shift

if [ "$ACTION" == "add" ]; then
    TIME=$1
    NAME=$2
    IS_REPEAT=$3
    shift
    shift
    shift
    MSG="$*"
    
    # Platform detection for notification command
    if [[ "$OSTYPE" == "darwin"* ]]; then
        NOTIFY_CMD="osascript -e 'display notification \"$MSG\" with title \"Reminder\"'"
    else
        # Check if notify-send exists
        if command -v notify-send &> /dev/null; then
            NOTIFY_CMD="notify-send 'Reminder' '$MSG'"
        else
            NOTIFY_CMD="echo 'Reminder: $MSG'"
        fi
    fi
    
    # Extract Hour and Minute from HH:MM
    HOUR=${TIME%:*} 
    MINUTE=${TIME#*:} 
    
    # Create a unique marker for this job to find/delete it later
    JOB_MARKER="# REMINDER_COBOL_$NAME"

    if [ "$IS_REPEAT" == "Y" ] || [ "$IS_REPEAT" == "y" ]; then
        # Handle Repeating Task (Daily)
        (crontab -l 2>/dev/null; echo "$MINUTE $HOUR * * * $NOTIFY_CMD $JOB_MARKER") | crontab -
        echo "Daily reminder scheduled for $TIME."
    else
        # One-time Task using cron with self-removal
        (crontab -l 2>/dev/null; echo "$MINUTE $HOUR * * * $NOTIFY_CMD; crontab -l 2>/dev/null | grep -v \"REMINDER_COBOL_$NAME\" | crontab - $JOB_MARKER") | crontab -
        echo "One-time reminder scheduled for $TIME."
    fi

elif [ "$ACTION" == "remove" ]; then
    ID_OR_NAME=$1
    if [ "$ID_OR_NAME" == "ALL" ]; then
        # Remove all cron reminders
        crontab -l 2>/dev/null | grep -v "REMINDER_COBOL" | crontab -
        echo "All reminders removed."
    else
        # Try removing from crontab (by name/marker)
        crontab -l 2>/dev/null | grep -v "REMINDER_COBOL_$ID_OR_NAME" | crontab -
        echo "Reminder '$ID_OR_NAME' removed (if it existed)."
    fi

elif [ "$ACTION" == "list" ]; then
    echo "--- Reminders (cron) ---"
    JOBS=$(crontab -l 2>/dev/null | grep "REMINDER_COBOL")
    if [ -z "$JOBS" ]; then
        echo "No reminders scheduled."
    else
        echo "$JOBS" | while read -r line; do
            NAME=$(echo "$line" | grep -o "REMINDER_COBOL_.*" | sed 's/REMINDER_COBOL_//')
            HOUR=$(echo "$line" | awk '{print $2}')
            MIN=$(echo "$line" | awk '{print $1}')
            if echo "$line" | grep -q "grep -v"; then
                TYPE="One-time"
            else
                TYPE="Daily"
            fi
            printf "% -10s | %s:%s | %s\n" "$TYPE" "$HOUR" "$MIN" "$NAME"
        done
    fi
fi